
function startPayment(){
    document.getElementById('screen-main').classList.add('hidden');
    document.getElementById('screen-processing').classList.remove('hidden');

    let sec = 300;
    let timer = document.getElementById("timer");
    let progress = document.getElementById("progress");

    let interval = setInterval(()=>{
        sec--;

        let m = String(Math.floor(sec/60)).padStart(2,'0');
        let s = String(sec%60).padStart(2,'0');
        timer.innerHTML = m + ":" + s;

        let percentage = ((300 - sec) / 300) * 100;
        progress.style.width = percentage + "%";

        if(sec <= 0){
            clearInterval(interval);
            document.getElementById('screen-processing').classList.add('hidden');
            document.getElementById('screen-approved').classList.remove('hidden');
        }
    }, 1000);
}
